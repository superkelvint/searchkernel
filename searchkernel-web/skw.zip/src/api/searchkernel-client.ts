/**
 * Browser-facing shape of the generated Search Kernel client.
 *
 * The dashboard depends on this contract, not on a transport or on fixture
 * storage. The fixture implementation is only one provider of this client.
 */
export type Capabilities = {
  indexes: { read: boolean; create: boolean; delete: boolean }
  documents: { read: boolean; write: boolean; bulk: boolean }
  search: { basic: boolean; sort: boolean; facets: boolean; grouping: boolean }
  analysis: { text: boolean }
  query: { inspect: boolean }
  schema: { read: boolean; write: boolean; changePlan: boolean }
  ranking: { profiles: boolean; features: boolean; write: boolean }
  summaries: { read: boolean; write: boolean }
  metrics: { query: boolean; storage: boolean }
  admin: { overview: boolean; health: boolean; diagnostics: boolean }
}

export type FieldValue = string | number | boolean | null | FieldValue[] | { [key: string]: FieldValue }

export type Document = {
  id: string
  fields: Record<string, FieldValue>
}

export type DisplayFormat = 'text' | 'number' | 'boolean' | 'date' | 'json'
export type FieldDisplay = { label: string; visible: boolean; order: number; format: DisplayFormat }
export type Field = {
  name: string
  type: string
  searchable: boolean
  attribute: boolean
  stored: boolean
  analyzer: string
  display: FieldDisplay
}

export type Index = {
  id: string
  documentCount: string
  size: string
  fieldCount: string
  latency: string
  documents: Document[]
  profiles: string[]
  summaries: string[]
  fields: Field[]
}

export type ClientSearchRequest = { query: string; ranking: string; limit: number; summary: string }
export type SearchHit = { document: Document; score: string; rank: number }
export type ClientSearchResponse = {
  request: ClientSearchRequest
  matches: number
  timingMs: string
  hits: SearchHit[]
  resolved: string
  analysis: string
  diagnostics: string[]
}
export type AnalysisToken = { position: number; original: string; normalized: string; term: string }
export type RequestOptions = { signal?: AbortSignal }
export type AnalysisOptions = RequestOptions & { field?: string }

export type ClientErrorDetails = Record<string, FieldValue>
export class SearchKernelClientError extends Error {
  readonly code: string
  readonly status?: number
  readonly retryable: boolean
  readonly details?: ClientErrorDetails

  constructor(message: string, options: { code?: string; status?: number; retryable?: boolean; details?: ClientErrorDetails } = {}) {
    super(message)
    this.name = 'SearchKernelClientError'
    this.code = options.code ?? 'client_error'
    this.status = options.status
    this.retryable = options.retryable ?? false
    this.details = options.details
  }
}

export function normalizeClientError(error: unknown): SearchKernelClientError {
  if (error instanceof SearchKernelClientError) return error
  if (typeof DOMException !== 'undefined' && error instanceof DOMException && error.name === 'AbortError') return new SearchKernelClientError('The request was cancelled.', { code: 'aborted' })
  if (error instanceof Error) {
    const candidate = error as Error & Partial<Omit<SearchKernelClientError, 'name' | 'message'>>
    return new SearchKernelClientError(error.message, { code: candidate.code ?? 'unknown_error', status: candidate.status, retryable: candidate.retryable ?? true, details: candidate.details })
  }
  if (typeof error === 'object' && error !== null) {
    const candidate = error as { code?: unknown; message?: unknown; status?: unknown; retryable?: unknown; details?: unknown }
    const details = typeof candidate.details === 'object' && candidate.details !== null ? candidate.details as ClientErrorDetails : undefined
    return new SearchKernelClientError(typeof candidate.message === 'string' ? candidate.message : 'The Search Kernel request failed.', { code: typeof candidate.code === 'string' ? candidate.code : 'unknown_error', status: typeof candidate.status === 'number' ? candidate.status : undefined, retryable: typeof candidate.retryable === 'boolean' ? candidate.retryable : true, details })
  }
  return new SearchKernelClientError('The Search Kernel request failed.', { code: 'unknown_error', retryable: true })
}

export interface SearchKernelClient {
  capabilities(): Promise<Capabilities>
  listIndexes(): Promise<Index[]>
  getIndex(indexId: string): Promise<Index | undefined>
  getDocument(indexId: string, documentId: string): Promise<Document | undefined>
  search(indexId: string, request: ClientSearchRequest, options?: RequestOptions): Promise<ClientSearchResponse>
  analyze(indexId: string, text: string, options?: AnalysisOptions): Promise<AnalysisToken[]>
}

export const initialSearchRequest: ClientSearchRequest = {
  query: 'wireless headphones',
  ranking: 'product-search',
  limit: 20,
  summary: 'search-result',
}

export const unsupportedCapabilityMessage = 'Unavailable because this capability is not exposed by the server.'
